package classes;

public class Antena {
	public Antena(int canalMinimo, int canalMaximo) {
		//TODO: 05 - Ajustar construtor da classe Antena
		//Dever� ser validado se o canalMinimo e o canalMaximo s�o maiores que 0. Caso contr�rio, lan�ar um erro.
		//Dever� ser validado se o canalMaximo � maior ou igual ao canalMinimo. Caso n�o seja, lan�ar um erro informando.
		//Os argumentos recebidos no construtor devem popular os atributos da classe

	}
	private int canalMinimo;
	private int canalMaximo;
	
	public boolean isCanalDisponivel(int canal) {
		//TODO: 06 - Implementar m�todo isCanalDisponivel
		//Este m�todo deve retornar true se canal estiver entre canalMinimo e canalMaximo,  e false, caso contr�rio.
		return false;
	}
	
	public int getCanalMinimo() {
		return canalMinimo;
	}
	
}
