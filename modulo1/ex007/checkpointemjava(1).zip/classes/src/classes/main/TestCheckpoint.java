package classes.main;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import classes.Antena;
import classes.Televisao;

public class TestCheckpoint {
	private Televisao televisao;
	private Antena antena;
	
	@Before
	public void setUp() {
		televisao = new Televisao("Samsung", "The Frame", 50);
		antena = new Antena(2, 13);
	}
	
	@Test
	public void testVolume() {
		Televisao televisao = new Televisao("Samsung", "The Frame", 50);
		assertEquals(0, televisao.getVolume());
		televisao.aumentarVolume();
		assertEquals(0, televisao.getVolume());
		televisao.ligarOuDesligar();
		assertEquals(0, televisao.getVolume());
		televisao.aumentarVolume();
		assertEquals(1, televisao.getVolume());
		televisao.mutarOuDesmutar();
		assertEquals(0, televisao.getVolume());
		televisao.aumentarVolume();
		assertEquals(2, televisao.getVolume());
		televisao.mutarOuDesmutar();
		assertEquals(0, televisao.getVolume());
		televisao.mutarOuDesmutar();
		assertEquals(2, televisao.getVolume());
		televisao.mutarOuDesmutar();
		assertEquals(0, televisao.getVolume());
		televisao.diminuirVolume();
		assertEquals(1, televisao.getVolume());
	}
	
	@Test
	public void testCanais() {
		televisao.ligarOuDesligar();
		televisao.conectar(antena);
		televisao.sincronizarCanais();
		assertEquals(2, televisao.getCanalAtual());
		televisao.irParaCanalAcima();
		televisao.irParaCanalAcima();
		televisao.irParaCanalAbaixo();
		televisao.irParaCanal(12);
		assertEquals(12, televisao.getCanalAtual());
	}
	
	@Test(expected = RuntimeException.class)
	public void testTentativaDeSincronizarSemAntena() {
		Televisao televisao = new Televisao("Samsung", "The Frame", 50);
		televisao.ligarOuDesligar();
		televisao.sincronizarCanais();
	}


	
	@Test(expected = RuntimeException.class)
	public void testIrParaCanalForaDaFaixa() {
		televisao.ligarOuDesligar();
		televisao.conectar(antena);
		televisao.sincronizarCanais();
		televisao.irParaCanal(14);	
	}
	
	@Test(expected = RuntimeException.class)
	public void testDiminuirParaCanalForaDaFaixa() {
		televisao.ligarOuDesligar();
		televisao.conectar(antena);
		televisao.sincronizarCanais();
		televisao.irParaCanalAbaixo();
	}


}
