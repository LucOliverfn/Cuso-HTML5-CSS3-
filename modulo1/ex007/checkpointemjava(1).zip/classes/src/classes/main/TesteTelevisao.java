package classes.main;

import classes.Televisao;

public class TesteTelevisao {
	public static void main(String[] args) {
		Televisao samsung = 
				new Televisao(
						"Samsung", "The Frame", 60);
		
		System.out.println("Minha tv eh da marca: " + samsung.getMarca());
		System.out.println("Minha tv eh do modelo: " + samsung.getModelo());
		System.out.println("Minha tv possui: " + samsung.getPolegadas() + " polegadas");
		System.out.println("Tv est� ligada? " + samsung.isLigada());
		System.out.println("Volume da tv: " + samsung.getVolume());		
		samsung.aumentarVolume();
		System.out.println("Volume da tv: " + samsung.getVolume());
		
		samsung.ligarOuDesligar();
		System.out.println("Tv est� ligada? " + samsung.isLigada());
		samsung.aumentarVolume();
		System.out.println("Volume da tv: " + samsung.getVolume());
		
		System.out.println("Canal atual da televis�o: " + samsung.getCanalAtual());
		samsung.sincronizarCanais();
		samsung.irParaCanal(5);
		System.out.println("Canal atual da televis�o: " + samsung.getCanalAtual());
		
		//Diminuir o canal 5x
		for (int i = 0; i < 5; i++) {
			samsung.irParaCanalAbaixo();
		}

		//Mostrar o valor do canal - 1
		System.out.println("Canal atual: " + samsung.getCanalAtual());

		//Aumentar o canal 50x
		for (int i = 0; i < 50; i++) {
			samsung.irParaCanalAcima();
		}
			
		//Mostrar o valor do canal - 51
		System.out.println("Canal atual: " + samsung.getCanalAtual());
		
		//Verificar o valor original do brilho ao ligar a tv
		//aumentar o brilho 10x
		//verificar o valor
		//Diminuir o brilho 20x
		//verificar o valor

	}
}
