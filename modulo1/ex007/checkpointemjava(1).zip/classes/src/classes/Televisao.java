package classes;

public class Televisao {
	private String marca;
	private int polegadas;
	private String modelo;
	private boolean ligada;
	private int volume;
	private Antena antena;

	public Televisao(String marca, String modelo, int polegadas) {
		if (marca == null || marca.equals("")) {
			throw new RuntimeException("Marca inv�lida");
		}
		
		if (modelo == null || modelo.equals("")) {
			throw new RuntimeException("Modelo inv�lido");
		}
		
		if (polegadas <= 20) {
			throw new RuntimeException("Polegadas inv�lida");
		}
		
		this.marca = marca;
		this.modelo = modelo;
		this.polegadas = polegadas;
	}
	
	public String getMarca() {
		return this.marca;
	}
	
	public String getModelo() {
		return this.modelo;
	}
	
	public int getPolegadas() {
		return this.polegadas;
	}
	
	public boolean isLigada() {
		return this.ligada;
	}
	
	public int getVolume() {
//TODO: 04 - Adicionar nova regra no m�todo "getVolume":
//			Se a TV estiver no mudo, este m�todo deve retornar sempre zero.
//			Sen�o, retorna o volume da TV.
		return this.volume;
	}
	
	public void ligarOuDesligar() {
		this.ligada = !ligada;
	}

	private boolean sincronizada;
	private int canalAtual;

	public void sincronizarCanais() {
//TODO: 07 - ajustar m�todo sincronizarCanais
//		Deve ser verificado se a tv est� ligada. caso n�o esteja, n�o faz nada.
//		Deve ser verificado se a antena est� conectada, utilizando o m�todo isAntenaConectada. Caso n�o esteja, lan�ar erro utilizando a classe RuntimeException.
//		Caso as condi��es acima sejam satisfeitas, o canal atual da tv deve passar ao canalMinimo da Antena.
		System.out.println("Sincronizando canais");
		this.sincronizada = true;
	}
	
	public int getCanalAtual() {
		return this.canalAtual;
	}
	
	public void irParaCanal(int numeroCanal) {
		
		if (this.isLigada()) {
			//TODO: 10 - alterar m�todo irParaCanal
//          Caso a TV n�o esteja sincronizada, lan�ar erro RuntimeException
//			deve ser chamado o m�todo "isCanalDisponivel" do objeto antena passando o canal desejado. Caso o canal n�o esteja dispon�vel, lan�ar erro utilizando RuntimeException.
//          Caso as condi��es acima estejam satisfeitas, alterar o atributo canalAtual para o canal desejado.
		}
	}
	
	public void irParaCanalAcima() {

		if (this.isLigada()) {
			//TODO: 09 - alterar m�todo irParaCanalAcima
//          Caso a TV n�o esteja sincronizada, lan�ar erro RuntimeException
//			Calcular qual o n�mero do canal desejado. (No caso, seria canalAtual + 1)
//			deve ser chamado o m�todo "isCanalDisponivel" do objeto antena passando o canal desejado. Caso o canal n�o esteja dispon�vel, lan�ar erro utilizando RuntimeException.
//          Caso as condi��es acima estejam satisfeitas, alterar o atributo canalAtual para o canal desejado.
		}
	}
	
	public void irParaCanalAbaixo() {

		if (this.isLigada()) {
			//TODO: 08 - alterar m�todo irParaCanalAbaixo
			//Caso a TV n�o esteja sincronizada, lan�ar erro utilizando RuntimeException
			//Calcular qual o n�mero do canal desejado. (No caso, seria canalAtual - 1)
			//deve ser chamado o m�todo "isCanalDisponivel" do objeto antena passando o canal desejado. Caso o canal n�o esteja dispon�vel, lan�ar erro utilizando RuntimeException.
			//Caso as condi��es acima estejam satisfeitas, alterar o atributo canalAtual para o canal desejado.
		}
	}
	
	public void aumentarVolume() {

		if (this.isLigada() && volume < 100) {
			//TODO: 02 - alterar m�todo aumentarVolume
			//Quando este m�todo for chamado, a TV deve sair do mudo.
			this.volume++;
		}
	}
	
	public void diminuirVolume() {

		if (this.isLigada() && volume > 0) {
			//TODO: 03 - alterar m�todo diminuirVolume
			//Quando este m�todo for chamado, a TV deve sair do mudo.
			this.volume--;
		}
	}

	public void mutarOuDesmutar() {
		//TODO: 01 - Criar m�todo "mutarOuDesmutar":
		//	 Se a tv n�o estiver ligada, o m�todo n�o deve fazer nada
		//	 Ao ser chamado a primeira vez a TV passa a estar no mudo
		//	 Ao ser chamado novamente, a TV sai do mudo.	
	}

	
	
	
	public void conectar(Antena antena) {
		this.antena = antena;
	}
	
	private boolean isAntenaConectada() {
		return this.antena != null;
	}
}
